
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rojen
 */
public class Schedule {
  private ArrayList<Day> days;
  int netHours;
  public Schedule(ArrayList<Day> days){
      this.days=days;
  }
  
            
}



