
import com.sun.glass.events.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.SpinnerModel;
import java.awt.*;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.event.*;
import java.text.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rojen
 */
public class Bookroom extends javax.swing.JFrame {

  
    File file = new File("./ScheduleSystem.db");
    User user;
    boolean signedIn;
    int day;
      /**
     * Creates new form Book
     */
    /**
     * Constructor initializes initial day for booking the room
     * @param Day Day is the initial day the room is booked
     * @throws ClassNotFoundException  Throws ClassNotFoundException if class is not found
     * @throws SQLException Throws SQLEception if database is not connected
     */
    public Bookroom(int Day) throws ClassNotFoundException, SQLException {
        signedIn = false;
        Class.forName("org.sqlite.JDBC");
        
        Connection connection = DriverManager.getConnection(DB_NAME);
        
        statement = connection.createStatement();
        
        initComponents();
        this.day = Day;
        DayLabel.setText("Day: " + day);
    }
    /**
     * Constructor initializes initial time room and day
     * @param time time is the initial time for booking a room
     * @param room room is  initial room to be booked
     * @param Day day is the date in which the room should be booked
     * @throws ClassNotFoundException Throws ClassNotFoundException if class is not found
     * @throws SQLException  Throws SQLEception if database is not connected
     */
    public Bookroom(String time, String room, int Day) throws ClassNotFoundException, SQLException {
        signedIn = false;
        Class.forName("org.sqlite.JDBC");
        
        Connection connection = DriverManager.getConnection(DB_NAME);
        
        statement = connection.createStatement();

        initComponents();
        
        TimeSpinner.setValue(time);
        RoomSpinner.setValue(room);
        this.day = Day;
        
        DayLabel.setText("Day: " + day);
        
    }
    /**
     * Constructor analyzes initial Day and user
     * @param Day Day is the day in which the room is booked
     * @param user user is the type of user can be Admin/ Student/teacher/Tutor
     * @throws ClassNotFoundException Throws ClassNotFoundException if class is not found
     * @throws SQLException Throws SQLEception if database is not connected
     */
    public Bookroom(int Day, User user) throws ClassNotFoundException, SQLException {
        signedIn = true;
        this.user = user;
        Class.forName("org.sqlite.JDBC");
        
        Connection connection = DriverManager.getConnection(DB_NAME);
        
        statement = connection.createStatement();
        
        initComponents();
        NameTextField.setText(user.getName());
        this.day = Day;
        DayLabel.setText("Day: " + day);
    }
    /**
     * Constructor analyzes initial time room day and user who booked the room
     * @param time time is initial time the room was booked 
     * @param room room is the initial room which was booked
     * @param Day Day is the initial day the room was booked on
     * @param user User is the type of user who booked the room
     * @throws ClassNotFoundException Throws ClassNotFoundException if class is not found
     * @throws SQLException Throws SQLEception if database is not connected
     */
    public Bookroom(String time, String room, int Day, User user) throws ClassNotFoundException, SQLException {
        signedIn = true;
        this.user = user;
        Class.forName("org.sqlite.JDBC");
        
        Connection connection = DriverManager.getConnection(DB_NAME);
        
        statement = connection.createStatement();

        initComponents();
        System.out.println(user.getName());
        NameTextField.setText(user.getName());
        TimeSpinner.setValue(time);
        RoomSpinner.setValue(room);
        this.day = Day;
        
        DayLabel.setText("Day: " + day);
        
    }
    private static final String DB_NAME = "jdbc:sqlite:ScheduleSystem.db";
    // Initializing the statement that's declared above
    /**
     * Statement for 
     */
    public static Statement statement;

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        RoomtextLabel = new javax.swing.JLabel();
        RoomLabel = new javax.swing.JLabel();
        EventTextField = new javax.swing.JTextField();
        TimeLabel = new javax.swing.JLabel();
        EventLabel = new javax.swing.JLabel();
        TimeSpinner = new javax.swing.JSpinner();
        SubmitButton = new javax.swing.JButton();
        RoomSpinner = new javax.swing.JSpinner();
        NameLabel = new javax.swing.JLabel();
        ContactLabel = new javax.swing.JLabel();
        NameTextField = new javax.swing.JTextField();
        ContactTextField = new javax.swing.JTextField();
        BackButton = new javax.swing.JButton();
        DayLabel = new javax.swing.JLabel();
        YSUIcon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(153, 0, 0));

        RoomtextLabel.setFont(new java.awt.Font("Old English Text MT", 1, 36)); // NOI18N
        RoomtextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        RoomtextLabel.setText("Room Scheduler");

        RoomLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        RoomLabel.setText("Room");

        EventTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EventTextFieldActionPerformed(evt);
            }
        });
        EventTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                EventTextFieldKeyPressed(evt);
            }
        });

        TimeLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        TimeLabel.setText("Time");

        EventLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        EventLabel.setText("Event");

        TimeSpinner.setModel(new javax.swing.SpinnerListModel(new String[] {"8", "9", "10", "11", "12", "1", "2", "3", "4", "5"}));
        TimeSpinner.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                TimeSpinnerKeyPressed(evt);
            }
        });

        SubmitButton.setBackground(new java.awt.Color(0, 0, 0));
        SubmitButton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        SubmitButton.setForeground(new java.awt.Color(153, 0, 0));
        SubmitButton.setText("Submit");
        SubmitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubmitButtonActionPerformed(evt);
            }
        });

        RoomSpinner.setModel(new javax.swing.SpinnerListModel(new String[] {"Conference Small", "Conference Suite", "Conference 524", "Lab 214", "Lab 403", "Lab 414"}));
        RoomSpinner.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                RoomSpinnerKeyPressed(evt);
            }
        });

        NameLabel.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        NameLabel.setText("Name");

        ContactLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        ContactLabel.setText("Contact Number ");

        NameTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                NameTextFieldKeyPressed(evt);
            }
        });

        ContactTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                ContactTextFieldKeyPressed(evt);
            }
        });

        BackButton.setBackground(new java.awt.Color(0, 0, 0));
        BackButton.setForeground(new java.awt.Color(153, 0, 0));
        BackButton.setText("Back");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });

        DayLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        DayLabel.setText("Day");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(BackButton)
                        .addGap(0, 409, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(RoomtextLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(YSUIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(151, 151, 151)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(DayLabel)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addComponent(NameLabel)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 78, Short.MAX_VALUE)
                                    .addComponent(NameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(ContactLabel)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(EventLabel)
                                            .addComponent(RoomLabel)))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(ContactTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                        .addComponent(RoomSpinner)
                                        .addComponent(EventTextField))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(TimeLabel)
                                .addGap(77, 77, 77)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(SubmitButton)
                                    .addComponent(TimeSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(BackButton)
                        .addGap(18, 18, 18)
                        .addComponent(RoomtextLabel))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(YSUIcon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NameLabel)
                    .addComponent(NameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ContactLabel)
                    .addComponent(ContactTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RoomSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RoomLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EventTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(EventLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TimeSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TimeLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(DayLabel)
                .addGap(18, 18, 18)
                .addComponent(SubmitButton)
                .addGap(40, 40, 40))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SubmitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubmitButtonActionPerformed
        // TODO add your handling code here:

        submit();

    }//GEN-LAST:event_SubmitButtonActionPerformed
    /**
     * Set Method for initializing the day
     * @param day Day is an int value which represents a day
     */
    public void setDay(int day) {
        this.day = day;
    }
    
    private void EventTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EventTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EventTextFieldActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        // TODO add your handling code here:
      Bookroom.this.setVisible(false);
      Resource room;
        try {
            if (signedIn) {
                room = new Resource(user);
                room.setVisible(true);
            }
            else {
                room = new Resource();
                room.setVisible(true);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Bookroom.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Bookroom.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_BackButtonActionPerformed

    private void NameTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_NameTextFieldKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            ContactTextField.grabFocus();
        }
    }//GEN-LAST:event_NameTextFieldKeyPressed

    private void ContactTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ContactTextFieldKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            RoomSpinner.grabFocus();
        }
    }//GEN-LAST:event_ContactTextFieldKeyPressed

    private void RoomSpinnerKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_RoomSpinnerKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            EventTextField.grabFocus();
        }
    }//GEN-LAST:event_RoomSpinnerKeyPressed

    private void EventTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_EventTextFieldKeyPressed
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            TimeSpinner.grabFocus();
        }
    }//GEN-LAST:event_EventTextFieldKeyPressed

    private void TimeSpinnerKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TimeSpinnerKeyPressed
        // TODO add your handling code here:
        submit();
    }//GEN-LAST:event_TimeSpinnerKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Bookroom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Bookroom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Bookroom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Bookroom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            try {
                new Bookroom(8).setVisible(true);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Bookroom.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Bookroom.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }
    
    public void submit() {
        String Name = NameTextField.getText();
        String Contact= ContactTextField.getText();
        String myEvent= EventTextField.getText();
        Object Room= RoomSpinner.getValue();
        Room=Room.toString();
        
        
        int Time = Integer.parseInt(TimeSpinner.getValue().toString());
         //Time= Time.toString();
         
        try {
            if (user.getLevel().equals("student") || user.getLevel().equals("tutor")) {
                myRequest request = new myRequest(RoomSpinner.getValue().toString() , Time , Name, Contact, myEvent, day);
                request.save(statement);
            }
            
            else {
                myEvent event = new myEvent(RoomSpinner.getValue().toString(), Time, Name, Contact, myEvent, day);
                event.save(statement);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Bookroom.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Bookroom.this.setVisible(false);
        Resource room;
        try {
            room = new Resource();
            room.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Bookroom.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Bookroom.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackButton;
    private javax.swing.JLabel ContactLabel;
    private javax.swing.JTextField ContactTextField;
    private javax.swing.JLabel DayLabel;
    private javax.swing.JLabel EventLabel;
    private javax.swing.JTextField EventTextField;
    private javax.swing.JLabel NameLabel;
    private javax.swing.JTextField NameTextField;
    private javax.swing.JLabel RoomLabel;
    private javax.swing.JSpinner RoomSpinner;
    private javax.swing.JLabel RoomtextLabel;
    private javax.swing.JButton SubmitButton;
    private javax.swing.JLabel TimeLabel;
    private javax.swing.JSpinner TimeSpinner;
    private javax.swing.JLabel YSUIcon;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables

}

